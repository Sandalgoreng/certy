<?php
require_once '../session.php';
cek_admin();
require_once '../koneksi.php';

if(isset($_POST['submit'])){
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    $stmt = $conn->prepare("INSERT INTO users(username, password, role) VALUES(?,?,?)");
    $stmt->bind_param("sss",$username,$password,$role);
    if($stmt->execute()){
        echo "<script>alert('Anggota berhasil ditambahkan');window.location='anggota.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan anggota');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Anggota</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<h2>Tambah Anggota Baru</h2>
<form method="post">
    <label>Username:</label>
    <input type="text" name="username" required><br><br>
    <label>Password:</label>
    <input type="password" name="password" required><br><br>
    <label>Role:</label>
    <select name="role">
        <option value="user">User</option>
        <option value="admin">Admin</option>
    </select><br><br>
    <button type="submit" name="submit">Tambah</button>
</form>

<a href="anggota.php">Kembali</a>
</body>
</html>
