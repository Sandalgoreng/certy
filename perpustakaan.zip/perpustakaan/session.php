<?php
session_start();

function cek_login(){
    if(!isset($_SESSION['username'])){
        header("Location: login.php");
        exit;
    }
}

function cek_admin(){
    if($_SESSION['role']!='admin'){
        echo "<div class='alert alert-danger'>Akses ditolak!</div>";
        exit;
    }
}
?>
