<?php
class Koneksi {
    private static $conn;

    public static function connect() {
        if(!self::$conn){
            $host = "localhost";
            $user = "root";
            $pass = "";
            $db   = "perpus"; // nama database

            self::$conn = new mysqli($host, $user, $pass, $db);
            if(self::$conn->connect_error){
                die("Koneksi gagal: ".self::$conn->connect_error);
            }
        }
        return self::$conn;
    }
}
?>
