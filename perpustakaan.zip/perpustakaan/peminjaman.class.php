<?php
require_once 'koneksi.php';

class Peminjaman {
    private $conn;

    public function __construct(){
        $this->conn = Koneksi::connect();
    }

    public function getPeminjaman($username=null){
        if($username){
            $stmt = $this->conn->prepare("
                SELECT p.id, p.id_buku, b.judul, p.username, p.tanggal_pinjam, p.tanggal_kembali, p.status 
                FROM peminjaman p 
                JOIN buku b ON p.id_buku=b.id 
                WHERE p.username=?
            ");
            $stmt->bind_param("s",$username);
            $stmt->execute();
            return $stmt->get_result();
        } else {
            $sql = "SELECT p.id, p.id_buku, b.judul, p.username, p.tanggal_pinjam, p.tanggal_kembali, p.status 
                    FROM peminjaman p 
                    JOIN buku b ON p.id_buku=b.id";
            return $this->conn->query($sql);
        }
    }

    public function pinjam($idBuku, $username){
        $buku = $this->conn->query("SELECT stok FROM buku WHERE id=$idBuku")->fetch_assoc();
        if($buku['stok']>0){
            $stmt = $this->conn->prepare("INSERT INTO peminjaman (id_buku,username,tanggal_pinjam,status) VALUES (?,?,NOW(),'dipinjam')");
            $stmt->bind_param("is",$idBuku,$username);
            if($stmt->execute()){
                $this->conn->query("UPDATE buku SET stok=stok-1 WHERE id=$idBuku");
                return true;
            }
        }
        return false;
    }

    public function kembali($idPeminjaman){
        $stmt = $this->conn->prepare("UPDATE peminjaman SET status='dikembalikan', tanggal_kembali=NOW() WHERE id=?");
        $stmt->bind_param("i",$idPeminjaman);
        if($stmt->execute()){
            $idBuku = $this->conn->query("SELECT id_buku FROM peminjaman WHERE id=$idPeminjaman")->fetch_assoc()['id_buku'];
            $this->conn->query("UPDATE buku SET stok=stok+1 WHERE id=$idBuku");
            return true;
        }
        return false;
    }
}
?>
