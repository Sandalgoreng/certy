<?php
require_once 'session.php';
require_once 'buku.class.php';
require_once 'peminjaman.class.php';
cek_login();

$bukuClass = new Buku();
$peminjaman = new Peminjaman();
$role = $_SESSION['role'];
$username = $_SESSION['username'];

$bukuList = $bukuClass->getAllBuku();
$pinjamUser = $peminjaman->getPeminjaman($username); // daftar buku user
$pinjamArray = [];
while($p = $pinjamUser->fetch_assoc()){
    if($p['status']=='dipinjam'){
        $pinjamArray[$p['id_buku']] = $p['id']; // id peminjaman
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Daftar Buku</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
<h2>Selamat datang, <?php echo $username ?> (<?php echo $role ?>)</h2>
<a href="logout.php" class="btn btn-danger mb-3">Logout</a>

<?php if($role=='admin'): ?>
<a href="tambah_buku.php" class="btn btn-success mb-3">Tambah Buku</a>
<a href="peminjaman.php" class="btn btn-info mb-3">Cek Semua Anggota & Peminjaman</a>
<?php endif; ?>

<table class="table table-bordered table-striped">
<tr>
<th>ID</th><th>Judul</th><th>Pengarang</th><th>Penerbit</th><th>Tahun</th><th>Stok</th>
<?php if($role=='admin'): ?>
<th>Created By</th><th>Peminjam</th><th>Aksi</th>
<?php else: ?>
<th>Status</th><th>Aksi</th>
<?php endif; ?>
</tr>

<?php while($row = $bukuList->fetch_assoc()): ?>
<tr>
<td><?php echo $row['id'] ?></td>
<td><?php echo $row['judul'] ?></td>
<td><?php echo $row['pengarang'] ?></td>
<td><?php echo $row['penerbit'] ?></td>
<td><?php echo $row['tahun_terbit'] ?></td>
<td><?php echo $row['stok'] ?></td>

<?php if($role=='admin'): ?>
<td><?php echo $row['created_by'] ?></td>
<td>
<?php
$pinjamList = $peminjaman->getPeminjaman();
$peminjamBuku = [];
while($p = $pinjamList->fetch_assoc()){
    if($p['id_buku']==$row['id'] && $p['status']=='dipinjam'){
        $peminjamBuku[] = $p['username'];
    }
}
echo !empty($peminjamBuku) ? implode(", ", $peminjamBuku) : "-";
?>
</td>
<td>
<a href="edit_buku.php?id=<?php echo $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
<a href="hapus_buku.php?id=<?php echo $row['id'] ?>" class="btn btn-sm btn-danger">Hapus</a>
</td>

<?php else: ?>
<td>
<?php
if(isset($pinjamArray[$row['id']])){
    echo "Dipinjam";
}else{
    echo "Tersedia";
}
?>
</td>
<td>
<?php if(isset($pinjamArray[$row['id']])): ?>
<!-- Tombol kembalikan -->
<a href="kembali.php?id=<?php echo $pinjamArray[$row['id']] ?>" class="btn btn-sm btn-warning">Kembalikan</a>
<?php elseif($row['stok']>0): ?>
<a href="pinjam.php?id=<?php echo $row['id'] ?>" class="btn btn-sm btn-success">Pinjam</a>
<?php endif; ?>
</td>
<?php endif; ?>
</tr>
<?php endwhile; ?>
</table>
</div>
</body>
</html>
