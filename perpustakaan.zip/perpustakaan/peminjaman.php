<?php
require_once 'session.php';
require_once 'peminjaman.class.php';
cek_login();
cek_admin();

$peminjaman = new Peminjaman();
$data = $peminjaman->getPeminjaman();
?>
<!DOCTYPE html>
<html>
<head>
<title>List Semua Peminjaman</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
<h3>List Semua Anggota & Peminjaman Buku</h3>
<a href="buku.php" class="btn btn-secondary mb-3">Kembali</a>

<table class="table table-bordered table-striped">
<tr>
<th>ID Peminjaman</th>
<th>Username</th>
<th>Buku</th>
<th>Status</th>
<th>Tanggal Pinjam</th>
<th>Tanggal Kembali</th>
</tr>

<?php while($row = $data->fetch_assoc()): ?>
<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['username']; ?></td>
<td><?php echo $row['judul']; ?></td>
<td><?php echo $row['status']; ?></td>
<td><?php echo $row['tanggal_pinjam']; ?></td>
<td><?php echo $row['tanggal_kembali'] ? $row['tanggal_kembali'] : '-'; ?></td>
</tr>
<?php endwhile; ?>
</table>
</div>
</body>
</html>
