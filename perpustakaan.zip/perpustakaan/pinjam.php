<?php
require_once 'session.php';
require_once 'peminjaman.class.php';
cek_login();

$username = $_SESSION['username'];
$peminjaman = new Peminjaman();

if(isset($_GET['id'])){
    $idBuku = $_GET['id'];
    if($peminjaman->pinjam($idBuku, $username)){
        $msg = "Buku berhasil dipinjam!";
    } else {
        $msg = "Gagal meminjam buku. Stok habis atau error!";
    }
    header("Location: buku.php"); // kembali ke daftar buku
    exit;
}
?>
