<?php
require_once 'koneksi.php';

class User {
    private $conn;

    public function __construct() {
        $this->conn = Koneksi::connect();
    }

    public function login($username, $password){
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE username=?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        if($result->num_rows>0){
            $user = $result->fetch_assoc();
            if($password === $user['password']){ // plaintext password
                return $user;
            }
        }
        return false;
    }

    public function getAllUser(){
        $sql = "SELECT username, role FROM users WHERE role='user'";
        return $this->conn->query($sql);
    }

    public function tambahUser($username, $password, $role='user'){
        $stmt = $this->conn->prepare("INSERT INTO users (username,password,role) VALUES (?,?,?)");
        $stmt->bind_param("sss", $username, $password, $role);
        return $stmt->execute();
    }
}
?>
