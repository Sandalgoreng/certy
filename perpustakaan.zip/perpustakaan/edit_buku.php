<?php
require 'koneksi.php';
require 'session.php';
cek_login();
cek_admin();

$conn = Koneksi::connect();
$id = $_GET['id'];
$sql = "SELECT * FROM buku WHERE id=$id";
$result = $conn->query($sql);
$data = $result->fetch_assoc();

if(isset($_POST['submit'])){
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $stok = $_POST['stok'];

    $sql = "UPDATE buku SET 
            judul='$judul',
            pengarang='$pengarang',
            penerbit='$penerbit',
            tahun_terbit='$tahun_terbit',
            stok='$stok'
            WHERE id=$id";
    
    if($conn->query($sql) === TRUE){
        header("Location: buku.php");
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<h2>Edit Buku</h2>
<form method="post">
    Judul: <input type="text" name="judul" value="<?= $data['judul'] ?>" required><br><br>
    Pengarang: <input type="text" name="pengarang" value="<?= $data['pengarang'] ?>" required><br><br>
    Penerbit: <input type="text" name="penerbit" value="<?= $data['penerbit'] ?>" required><br><br>
    Tahun Terbit: <input type="number" name="tahun_terbit" value="<?= $data['tahun_terbit'] ?>" required><br><br>
    Stok: <input type="number" name="stok" value="<?= $data['stok'] ?>" required><br><br>
    <input type="submit" name="submit" value="Update">
</form>
<a href="buku.php">Kembali</a>
