<?php
require_once 'koneksi.php';

class Buku {
    private $conn;

    public function __construct() {
        $this->conn = Koneksi::connect();
    }

    public function getAllBuku(){
        $sql = "SELECT * FROM buku";
        return $this->conn->query($sql);
    }

    public function getBukuById($id){
        $stmt = $this->conn->prepare("SELECT * FROM buku WHERE id=?");
        $stmt->bind_param("i",$id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function tambahBuku($judul, $pengarang, $penerbit, $tahun, $stok, $created_by){
        $stmt = $this->conn->prepare("INSERT INTO buku (judul,pengarang,penerbit,tahun_terbit,stok,created_by) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("sssiss",$judul,$pengarang,$penerbit,$tahun,$stok,$created_by);
        return $stmt->execute();
    }

    public function editBuku($id, $judul, $pengarang, $penerbit, $tahun, $stok){
        $stmt = $this->conn->prepare("UPDATE buku SET judul=?, pengarang=?, penerbit=?, tahun_terbit=?, stok=? WHERE id=?");
        $stmt->bind_param("sssiii",$judul,$pengarang,$penerbit,$tahun,$stok,$id);
        return $stmt->execute();
    }

    public function hapusBuku($id){
        $stmt = $this->conn->prepare("DELETE FROM buku WHERE id=?");
        $stmt->bind_param("i",$id);
        return $stmt->execute();
    }
}
?>
