<?php
require 'koneksi.php';
require 'session.php';
cek_login();
cek_admin();

$conn = Koneksi::connect();
$id = $_GET['id'];
$sql = "DELETE FROM buku WHERE id=$id";

if($conn->query($sql) === TRUE){
    header("Location: buku.php");
} else {
    echo "Error: " . $conn->error;
}
?>
