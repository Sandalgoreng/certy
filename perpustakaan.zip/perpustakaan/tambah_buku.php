<?php
require 'koneksi.php';
require 'session.php';
cek_login();
cek_admin();

if(isset($_POST['submit'])){
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun = $_POST['tahun_terbit'];
    $stok = $_POST['stok'];
    $created_by = $_SESSION['username'];

    $conn = Koneksi::connect();
    $sql = "INSERT INTO buku (judul,pengarang,penerbit,tahun_terbit,stok,created_by)
            VALUES ('$judul','$pengarang','$penerbit','$tahun','$stok','$created_by')";
    $conn->query($sql);
    header("Location: buku.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Tambah Buku</title>
<style>
body{font-family:sans-serif;background:#f4f6f8;padding:20px;}
h2{text-align:center;color:#2c3e50;}
form{background:#fff;padding:20px;max-width:500px;margin:0 auto;border-radius:8px;box-shadow:0 0 10px rgba(0,0,0,0.05);}
form label{display:block;margin-top:15px;color:#2c3e50;}
form input[type=text], form input[type=number]{width:100%;padding:10px;margin-top:5px;border:1px solid #ccc;border-radius:5px;}
form input[type=submit]{margin-top:20px;width:100%;padding:10px;background:#3498db;color:#fff;border:none;border-radius:5px;cursor:pointer;transition:0.3s;}
form input[type=submit]:hover{background:#1abc9c;}
a{text-decoration:none;color:#2980b9;margin-top:10px;display:inline-block;}
a:hover{color:#1abc9c;}
</style>
</head>
<body>
<h2>Tambah Buku</h2>
<form method="post">
    <label>Judul Buku</label>
    <input type="text" name="judul" required>
    
    <label>Pengarang</label>
    <input type="text" name="pengarang" required>
    
    <label>Penerbit</label>
    <input type="text" name="penerbit" required>
    
    <label>Tahun Terbit</label>
    <input type="number" name="tahun_terbit" required>
    
    <label>Stok</label>
    <input type="number" name="stok" required>
    
    <input type="submit" name="submit" value="Simpan">
</form>
<a href="buku.php">Kembali ke Buku</a>
</body>
</html>
