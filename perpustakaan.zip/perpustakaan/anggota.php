<?php
require_once '../session.php';
cek_admin();
require_once '../koneksi.php';

// Hapus anggota
if(isset($_GET['hapus'])){
    $id = $_GET['hapus'];
    if($id != $_SESSION['id']){ // jangan hapus diri sendiri
        $conn->query("DELETE FROM users WHERE id='$id'");
        echo "<script>alert('Anggota berhasil dihapus');window.location='anggota.php';</script>";
    } else {
        echo "<script>alert('Anda tidak bisa menghapus diri sendiri');</script>";
    }
}

// Ambil semua user
$users = $conn->query("SELECT * FROM users");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Anggota</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<h2>Daftar Anggota</h2>
<a href="tambah_anggota.php">Tambah Anggota</a>
<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Role</th>
        <th>Aksi</th>
    </tr>
    <?php while($user = $users->fetch_assoc()): ?>
    <tr>
        <td><?= $user['id'] ?></td>
        <td><?= $user['username'] ?></td>
        <td><?= $user['role'] ?></td>
        <td>
            <a href="anggota.php?hapus=<?= $user['id'] ?>" onclick="return confirm('Yakin hapus anggota?')">Hapus</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<a href="dashboard.php">Kembali ke Dashboard</a>
</body>
</html>
