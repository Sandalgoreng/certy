<?php
require_once '../session.php';
cek_admin();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<h1>Selamat Datang, Admin <?= $_SESSION['username'] ?></h1>

<nav>
    <a href="buku.php">Daftar Buku</a> |
    <a href="peminjaman.php">Peminjaman</a> |
    <a href="anggota.php">Kelola Anggota</a> |
    <a href="../logout.php">Logout</a>
</nav>

<p>Pilih menu di atas untuk mengelola perpustakaan.</p>

</body>
</html>
