<?php
require 'koneksi.php';
require 'session.php';
cek_login();
cek_admin();

$conn = Koneksi::connect();
$sql = "SELECT username, role FROM users WHERE role='user'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
<title>Daftar User</title>
<style>
body{font-family:sans-serif;background:#f4f6f8;padding:20px;}
h2{text-align:center;color:#2c3e50;}
table{width:50%;margin:0 auto;border-collapse:collapse;background:#fff;box-shadow:0 0 10px rgba(0,0,0,0.05);}
th,td{padding:12px;text-align:left;border-bottom:1px solid #ddd;}
th{background:#3498db;color:#fff;}
tr:nth-child(even){background:#f2f2f2;}
a{text-decoration:none;color:#2980b9;}
a:hover{color:#1abc9c;}
</style>
</head>
<body>
<h2>Daftar User</h2>
<a href="buku.php">Kembali ke Buku</a> | <a href="logout.php">Logout</a>
<table border="1">
<tr>
<th>Username</th>
<th>Role</th>
</tr>

<?php
if($result->num_rows > 0){
    while($row=$result->fetch_assoc()){
        echo "<tr><td>".$row['username']."</td><td>".$row['role']."</td></tr>";
    }
}else{
    echo "<tr><td colspan='2'>Tidak ada user</td></tr>";
}
?>
</table>
</body>
</html>
