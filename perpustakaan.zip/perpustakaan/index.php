<?php
session_start();
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}

// Semua file di satu folder
header("Location: buku.php");
exit;
?>
