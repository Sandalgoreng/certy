<?php
require_once __DIR__ . "/model/Anggota.php";
$a = new Anggota();
$data = $a->tampil();
?>

<h2>Data Anggota</h2>

<table border="1">
<tr>
    <th>ID</th>
    <th>Nama</th>
</tr>

<?php while ($row = $data->fetch_assoc()): ?>
<tr>
    <td><?= $row['id_anggota'] ?></td>
    <td><?= $row['nama'] ?></td>
</tr>
<?php endwhile; ?>
</table>

<a href="index.php">⬅ Kembali</a>
