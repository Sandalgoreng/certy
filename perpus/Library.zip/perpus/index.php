<h1>Sistem Perpustakaan</h1>
<ul>
    <li><a href="buku.php">Data Buku</a></li>
    <li><a href="anggota.php">Data Anggota</a></li>
    <li><a href="pinjam.php">Peminjaman</a></li>
</ul>
