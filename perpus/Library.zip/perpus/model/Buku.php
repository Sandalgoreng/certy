<?php
require_once __DIR__ . "/../config/koneksi.php";

class Buku {

    public function tampil() {
        return Koneksi::connect()->query("SELECT * FROM buku");
    }

    public function simpan($judul, $penulis) {
        $db = Koneksi::connect();
        $stmt = $db->prepare(
            "INSERT INTO buku (judul, penulis) VALUES (?, ?)"
        );
        $stmt->bind_param("ss", $judul, $penulis);
        return $stmt->execute();
    }
}
